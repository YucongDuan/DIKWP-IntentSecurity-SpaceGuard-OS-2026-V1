# 30-Day Pilot Plan

## Week 1: Scope and boundary
- select 3 low-risk data assets
- register owners, affected subjects, legal bases, declared intents and prohibited intents
- build DIKWP Content Cards and Evidence Ledger

## Week 2: Intent-space modeling
- define lawful and nonlegal intent registry
- create stakeholder intent contracts
- map content-intent edges
- run 3-No and purpose-drift simulations

## Week 3: Security modules and tickets
- run the 25 DIKWP×DIKWP security module review
- generate C2-C5 Action Tickets
- test human gates and kill conditions

## Week 4: Review and passport
- legal/compliance/security/business/auditor review
- generate IntentSecurity Passport
- decide: allow, narrow, sandbox, block or escalate

## Acceptance criteria
- no production data without authorization
- no attack instructions or nonlegal operational guidance
- every C4/C5 edge has a human gate
- purpose drift kills old evaluation
- affected subjects and rights are visible
- at least one passport and one failed-case review completed
