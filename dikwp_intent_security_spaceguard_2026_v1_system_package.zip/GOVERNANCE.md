# Governance and Safety Boundary

## Redefined safety

Data security is not complete if it only protects raw data objects. DIKWP security requires that D/I/K/W/P content remains within lawful, authorized, proportional, auditable intent space.

## Prohibited uses
- generating attack instructions or operational evasion plans
- re-identification, stalking, or unauthorized tracking
- discriminatory high-impact profiling
- coercive persuasion or manipulation
- unauthorized AI training, model extraction, or dataset laundering
- production authorization without human review
- legal, accounting, compliance, or certification conclusions

## Human gates
C4 and C5 outputs require review by security, legal/compliance, data protection, business owner, and auditor roles as appropriate.

## Kill conditions
Stop or block when:
- intent class is nonlegal
- purpose is imprecise or drifts from authorization
- rights basis is absent or unclear
- data subject or affected party is hidden
- content can support cyber/offensive, discriminatory, coercive, surveillance, or unauthorized training use
- audit trail is unavailable
- model output tries to act as final legal or security decision
