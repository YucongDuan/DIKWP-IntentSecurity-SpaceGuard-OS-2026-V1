#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from datetime import datetime, timezone

def classify(asset,intent):
    fit=intent.get('fit',{}).get(asset.get('domain',''),50)
    sensitivity=asset.get('sensitivity',70); rights=asset.get('rights',50); audit=asset.get('audit',50)
    base=intent.get('risk',50)
    risk=round(fit*.35+sensitivity*.22+(100-rights)*.15+(100-audit)*.10+base*.18)
    if intent.get('class')=='nonlegal': risk=max(risk,85)
    level='C5' if risk>=85 else 'C4' if risk>=70 else 'C3' if risk>=55 else 'C2' if risk>=40 else 'C1'
    decision='block' if level=='C5' or intent.get('class')=='nonlegal' else 'escalate' if level=='C4' else 'sandbox_or_narrow' if level=='C3' else 'allow_with_log'
    return {"fit":fit,"risk":risk,"level":level,"decision":decision}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('case',type=Path);ap.add_argument('--out',type=Path,default=Path('outputs'))
    args=ap.parse_args();case=json.loads(args.case.read_text(encoding='utf-8'))
    score=classify(case['asset'],case['intent'])
    passport={"version":"DIKWP IntentSecurity SpaceGuard OS 2026 V1","generated_at":datetime.now(timezone.utc).isoformat(),"synthetic":case.get('synthetic',True),"asset":case['asset'],"intent":case['intent'],"score":score,"boundaries":{"legal_opinion":False,"attack_guidance":False,"human_review_required":True}}
    args.out.mkdir(parents=True,exist_ok=True);target=args.out/'intent_security_passport.json';target.write_text(json.dumps(passport,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(score,ensure_ascii=False,indent=2));print('Output:',target)
if __name__=='__main__':main()
