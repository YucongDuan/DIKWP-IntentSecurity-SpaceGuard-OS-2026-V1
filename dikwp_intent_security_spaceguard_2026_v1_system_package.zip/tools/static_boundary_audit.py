#!/usr/bin/env python3
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
PATTERNS=[(r"\brequests\.","network requests"),(r"\burllib\.request","URL access"),(r"\bsocket\.","raw sockets"),(r"\beval\(","dynamic eval"),(r"\bexec\(","dynamic exec"),(r"\bos\.system","shell execution"),(r"broker|exchange|production control|exploit steps|payload","prohibited operational content")]
EXCLUDE={"static_boundary_audit.py","static_boundary_audit_report.json"}
def main():
    findings=[]
    for p in ROOT.rglob('*'):
        if not p.is_file() or p.name in EXCLUDE or p.suffix.lower() not in {'.py','.html','.js','.json','.md'}: continue
        text=p.read_text(encoding='utf-8',errors='ignore')
        for pat,meaning in PATTERNS:
            if re.search(pat,text,re.I): findings.append({'file':str(p.relative_to(ROOT)),'meaning':meaning})
    result={'package':'DIKWP IntentSecurity SpaceGuard OS 2026 V1','hidden_network_or_operational_attack_content_detected':bool(findings),'findings':findings,'note':'String matches require human review; this is not a security certification.'}
    out=ROOT/'static_boundary_audit_report.json';out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
